/**
 * Minecraft EasyProxi — Backend Server
 * Node.js + Express + Socket.IO + WebRTC + Microsoft OAuth
 */

// Load .env file if present
try { require('dotenv').config(); } catch(e) {}

const express = require('express');
const http    = require('http');
const { Server } = require('socket.io');
const cors    = require('cors');
const path    = require('path');

const routes      = require('./routes');
const { initSocket } = require('./socket');
const msAuth      = require('./auth/microsoft');

const app    = express();
const server = http.createServer(app);

// ─── Socket.IO ────────────────────────────────────────────────────────────────
const io = new Server(server, {
  cors: { origin: process.env.FRONTEND_URL || '*', methods: ['GET', 'POST'] },
});

// ─── Middleware ───────────────────────────────────────────────────────────────
app.use(cors({ origin: process.env.FRONTEND_URL || '*', credentials: true }));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// ─── Static frontend ─────────────────────────────────────────────────────────
app.use(express.static(path.join(__dirname, '../frontend')));

// ─── API routes ───────────────────────────────────────────────────────────────
app.use('/api', routes);
app.use('/api/modrinth', require('./modrinth'));

// ─── Microsoft OAuth routes ───────────────────────────────────────────────────
app.use('/api/auth', msAuth);

// ─── Socket.IO ────────────────────────────────────────────────────────────────
initSocket(io);

// ─── SPA fallback ─────────────────────────────────────────────────────────────
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, '../frontend/index.html'));
});

// ─── Start ────────────────────────────────────────────────────────────────────
const PORT = process.env.PORT || 3000;
server.listen(PORT, () => {
  const msConfigured = !!(process.env.MS_CLIENT_ID && process.env.MS_CLIENT_ID !== 'YOUR_AZURE_CLIENT_ID');
  console.log(`
╔══════════════════════════════════════════╗
║   Minecraft EasyProxi Backend v1.0       ║
║   http://localhost:${PORT}                   ║
║   Microsoft OAuth: ${msConfigured ? '✓ Configured' : '⚠ Not configured'}      ║
╚══════════════════════════════════════════╝

API routes:
  GET  /api/health
  GET  /api/status
  POST /api/login
  POST /api/register
  POST /api/session/start
  DELETE /api/session/:id
  GET  /api/auth/status
  POST /api/auth/microsoft/callback
  GET  /api/auth/me

${!msConfigured ? `⚠  Microsoft OAuth not configured.
   Add MS_CLIENT_ID and MS_CLIENT_SECRET to your .env file.
   See backend/auth/microsoft.js for setup instructions.\n` : ''}
  `);
});

module.exports = { app, server, io };
